# Email-Marketing-Automation-Software
 Use This FREE SOFTWARE to Automate Emails using Python, this BOT can send single email, and you can send bulk emails using excel file.
# Set up the Bot:
 1. Install the latest version of Python<br>
 2. Add your email, and your app password in the text file: important.txt<br>
 3. Watch this full tutorial on how to use this bot step by step<br>
    > https://youtu.be/56x67TBOZSE
